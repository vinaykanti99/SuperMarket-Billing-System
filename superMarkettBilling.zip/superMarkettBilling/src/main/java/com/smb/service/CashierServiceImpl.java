package com.smb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smb.dao.CashierDAO;
import com.smb.model.Cashier;

@Service(value = "cashierService")
@Transactional
public class CashierServiceImpl implements CashierService{
	@Autowired
	CashierDAO cashierDAO;
	
	public String addCashier(Cashier cashier)  {
//		if(cashierDAO.getCashier(cashier.getCid())!=null) {
//			throw new Exception("Cashier already Exists");
//		}
		
		try {
			int id=cashierDAO.addCashier(cashier);
			if(id==cashier.getCid()) {
				return "success";
			}
			else {
				return "AlreadyPresent";
			}
		}
		catch(Exception e) {
			return "Failed";
		}
		
	}

	public Cashier getCashier(Integer cid) throws Exception {
		return cashierDAO.getCashier(cid);
		
	}

	public String updateCashier(Integer CashierID,String CashierName,Integer MobileNumber,String Address,String EmailID,String Password) throws Exception {
		Cashier c=this.getCashier(CashierID);
		if(c==null) {
			
			return "NotFound";
		}
		String a=cashierDAO.updateCashier(CashierID, CashierName, MobileNumber, Address, EmailID, Password);
		
		System.out.println("update cashier "+a);
		return a;
	}

	public Integer deleteCashier(Integer cid) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}



}

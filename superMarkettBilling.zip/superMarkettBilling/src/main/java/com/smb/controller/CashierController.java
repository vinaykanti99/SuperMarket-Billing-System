package com.smb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.smb.model.Cashier;
import com.smb.service.CashierService;
import com.smb.service.LoginService;


@Controller
@RequestMapping(value="/")
public class CashierController {
	@Autowired
	CashierService cashierService;
	@Autowired
	LoginService loginService;
	@GetMapping(value="/cashier")
	public ModelAndView enrollCashier() {
		if(loginService.verifyadmin()==1) {
			return new ModelAndView("CashierEnroll");
		}
		else {
				return new ModelAndView("redirect:/");
			}
		
	}
	@GetMapping(value="/cashierUpdate")
	public ModelAndView UpdateCashier() {
		if(loginService.verifyadmin()==1) {
			return new ModelAndView("CashierUpdate");
		}
		else {
				return new ModelAndView("redirect:/");
			}
	}
	@GetMapping(value="/cashier/addcashier")
	public ModelAndView addCashier(@RequestParam Integer CashierID,
			@RequestParam String CashierName,@RequestParam Integer MobileNumber,
			@RequestParam String Address,@RequestParam String EmailID,@RequestParam String Password) {
		Cashier c=new Cashier();
		c.setCid(CashierID);
		c.setName(CashierName);
		c.setMobileno(MobileNumber);
		c.setEmailid(EmailID);
		c.setAddress(Address);
		c.setPassword(Password);
		String a;
		try {
			a = cashierService.addCashier(c);
			
			if(a.equals("success")) {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.You have successfully Added a cashier";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			else if(a.equals("AlreadyPresent")) {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Cashier Already Exists  a cashier";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			else {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Unable to add cashier";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
		} catch (Exception e) {
			return new ModelAndView("ErrorPage");
		}
		
	}
	@GetMapping(value="/cashierupdate/update")
	public ModelAndView updateCashier(@RequestParam Integer CashierID,
			@RequestParam String CashierName,@RequestParam Integer MobileNumber,
			@RequestParam String Address,@RequestParam String EmailID,@RequestParam String Password) {
		try {
		
				String cond=cashierService.updateCashier(CashierID,CashierName,MobileNumber,Address,EmailID,Password);
			
			if(cond.equals("success")) {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.You have successfully Updated "+CashierName.toUpperCase()+" a cashier";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			
			else if(cond.equals("NotFound")){
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Cashier does not exists.";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
			else {
				ModelAndView modelAndView = new ModelAndView("SuccessPage_Admin");
				String message="Dear Admin.Unable to update cashier";
				modelAndView.addObject("Message", message);
				return modelAndView;
			}
		} catch (Exception e) {
			return new ModelAndView("ErrorPage");
		}
		
	}
	


}

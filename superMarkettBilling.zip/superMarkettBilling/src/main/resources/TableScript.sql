drop table Cashier cascade constraints;
drop table Admin cascade constraints;
drop table Product cascade constraints;
create table Cashier (
	cid number(10) not null,
	name varchar2(20),
	mobileno number(15),
	emailid varchar2(30),
	address varchar2(30),
	password varchar2(20),
	primary key (cid)
);
create table Admin (
	aid number(10) not null,
	name varchar2(20),
	password varchar2(20),
	primary key (aid)
);
create table Product (
	pid number(10) not null,
	pname varchar2(20),
	quantity number(10),
	amount number(10),
	description varchar2(30),
	primary key (pid)
);
insert into Cashier (cid, name, mobileno, emailid,address,password) values (1001,'Theja',9751151076,'theja@infy.com','pallipattu,TN','Theja122');
insert into Admin(aid,name,password) values (100,'Ramya','Ramya@1998');
insert into Product(pid,pname,quantity,amount,description) values (21,'Maggi',7,20,'Maggi noodles');



commit;
select * from Cashier;
select * from Admin;
select * from product;
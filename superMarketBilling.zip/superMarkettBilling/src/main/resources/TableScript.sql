drop table Cashier cascade constraints;
drop table Admin cascade constraints;
drop table Product cascade constraints;
create table Cashier (
	cid number(10) not null,
	name varchar2(20),
	mobileno number(15),
	emailid varchar2(30),
	address varchar2(30),
	password varchar2(20),
	primary key (cid)
);
create table Admin (
	aid number(10) not null,
	name varchar2(20),
	password varchar2(20),
	primary key (aid)
);
create table Product (
	pid number(10) not null,
	pname varchar2(20),
	quantity number(10),
	amount number(10),
	description varchar2(30),
	primary key (pid)
);
insert into Cashier (cid, name, mobileno, emailid,address,password) values (1001,'Arifa',9751151076,'arifa@hcl.com','guntur,AP','arifa@5359');
insert into Admin(aid,name,password) values (100,'Ramya','Ramya@1998');
insert into Admin(aid,name,password) values (101,'somu','somu@2115');
insert into Admin(aid,name,password) values (103,'aditya','adi@103');
insert into Admin(aid,name,password) values (104,'jeeva','jeeva@1998');
insert into Admin(aid,name,password) values (105,'vinay','apollonatwest');
insert into Admin(aid,name,password) values (106,'nihal','tiger');
insert into Product(pid,pname,quantity,amount,description) values (21,'Maggi',7,20,'Maggi noodles');



commit;
select * from Cashier;
select * from Admin;
select * from product;
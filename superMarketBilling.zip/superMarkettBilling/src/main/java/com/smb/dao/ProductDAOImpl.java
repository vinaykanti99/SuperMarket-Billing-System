package com.smb.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.smb.entity.ProductEntity;
import com.smb.model.Product;
@Repository(value="productDAO")
public class ProductDAOImpl implements ProductDAO {
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Integer addProduct(Product product) throws Exception {
		Integer cidOut=null;
		
		ProductEntity ce=new ProductEntity();
		ce.setPid(product.getPid());
		ce.setPname(product.getPname());
		ce.setQuantity(product.getQuantity());
		ce.setAmount(product.getAmount());
		ce.setDescription(product.getDescription());
		cidOut=ce.getPid();
		entityManager.persist(ce);
		return cidOut;
	}

	@Override
	public Product getProduct(Integer ProductId) throws Exception {
		Product product=null;
		ProductEntity pe=entityManager.find(ProductEntity.class, ProductId);
		if(pe!=null) {
			product =new Product();
			product.setPid(pe.getPid());
			product.setPname(pe.getPname());
			product.setQuantity(pe.getQuantity());
			product.setAmount(pe.getAmount());
			product.setDescription(pe.getDescription());
			
		}
		return product;
	}

	@Override
	public String updateStock(Integer ProductId, Integer quantity) throws Exception {
		String out=null;
		ProductEntity pe=entityManager.find(ProductEntity.class, ProductId);
		if(pe!=null) {
			pe.setQuantity(quantity);
			out="success";
		}
		return out;
	}

}

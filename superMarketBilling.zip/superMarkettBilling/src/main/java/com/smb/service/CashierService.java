package com.smb.service;

import com.smb.model.Cashier;

public interface CashierService {
	public String addCashier(Cashier cashier) throws Exception;
	public Cashier getCashier(Integer cid) throws Exception;
	public String updateCashier(Integer CashierID,String CashierName,Integer MobileNumber,String Address,String EmailID,String Password)throws Exception;
	public Integer deleteCashier(Integer cid)throws Exception;
}

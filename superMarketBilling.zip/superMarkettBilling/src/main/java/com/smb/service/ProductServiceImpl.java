package com.smb.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.smb.dao.ProductDAO;
import com.smb.model.Product;
@Service(value = "productService")
@Transactional
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductDAO productDAO;

	@Override
	public String addProduct(Product product) throws Exception {
		
		try {
			int id=productDAO.addProduct(product);
			if(id==product.getPid()) {
				return "success";
			}
			else {
				return "AlreadyPresent";
			}
		}
		catch(Exception e) {
			return "Failed";
		}
		
	}

	@Override
	public Product getProduct(Integer pId) throws Exception {
		
		return productDAO.getProduct(pId);
	}

	@Override
	public String updateStock(Integer pId, Integer quantity) throws Exception {
		Product c=this.getProduct(pId);
		if(c==null) {
			return new String("NotFound");
		}
		String a=productDAO.updateStock(pId, quantity);
		return a;
	}

	

}

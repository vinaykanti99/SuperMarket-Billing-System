package com.smb;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.smb.service.CashierService;

@SpringBootApplication
public class SuperMartBillingApplication{
	@Autowired
	CashierService cashierService;
	
	public static void main(String[] args) {
		SpringApplication.run(SuperMartBillingApplication.class, args);
		
	}//http://localhost:3000/

}

package com.smb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.smb.service.CashierService;
import com.smb.service.LoginService;

@Controller
@RequestMapping(value="/login")
public class LoginController {
	public int a=2;
	@Autowired
	CashierService cashierService;
	@Autowired
	LoginService loginService;
	@GetMapping(value="/admin")
	public ModelAndView adminLogin() {
	
		return new ModelAndView("AdminLogin");
	}
	@GetMapping(value="/cashier")
	public ModelAndView cashierLogin() {
		return new ModelAndView("CashierLogin");
	}
	@GetMapping(value="/AdminRedirect")
	public ModelAndView AadminRedirect() {
		if(a==1) {
			return new ModelAndView("AdminAuthSuccess");
		}
		else {
			return new ModelAndView("redirect:/login/admin");
		}
	}
	@GetMapping(value="/admin/authenticate")
	public ModelAndView authAdmin(@RequestParam Integer AdminID,
			@RequestParam String Password) {	
		String auth=loginService.authAdmin(AdminID,Password);
		System.out.println("auth :"+auth);
		if(auth.equals("success")) {
			a=1;
		
			return new ModelAndView("AdminAuthSuccess");
		}
		else if(auth.equals("failed"))
		{
			//System.out.println("failed enter");
			return new ModelAndView("AdminAuthFailed");
		}
		else{
			return new ModelAndView("ErrorPage");
		}
		}
	@GetMapping(value="/Cashier/authenticate")
	public ModelAndView authCashier(@RequestParam Integer CashierID,
			@RequestParam String Password) {
		String auth=loginService.authCashier(CashierID,Password);
		
		if(auth.equals("success")) {
			
			return new ModelAndView("CashierLoginSuccess");
		}
		else if(auth.equals("failed"))
		{
			//System.out.println("failed enter");
			return new ModelAndView("CashierLoginFailed");
		}
		else{
			return new ModelAndView("ErrorPage");
		}
	}
	
}
